STAGE 2A AUDIT EVIDENCE

Two source corrections only: biometric CHECK parenthesis and parents pair index declaration.
Native raw export execution remains RED (42830); all 1,189 statements pass in dependency order with an identical statement multiset.
All database connections used explicit Unix sockets in a disposable /tmp cluster with TCP disabled. No shared database/configuration/secret mutation, migration, push, preview approval or publish was performed.
Before catalog is a diagnostic projection omitting only the invalid biometric CHECK and rejecting the unsupported parents FK. After catalog contains the complete unmodified model in dependency order.
No raw SQL export, executable migration, credentials, shared-data rows or reusable execution script is supplied in this bundle. SQL snippets inside JSON and the two-definition diff are audit evidence only.
Independent current shared/deployed state was NOT VERIFIED; see Section E.
